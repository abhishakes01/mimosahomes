import EditFloorPlanClient from "./EditFloorPlanClient";

export const dynamic = 'force-dynamic';

export default function EditFloorPlanPage() {
    return <EditFloorPlanClient />;
}
