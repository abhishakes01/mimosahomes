import CreateFloorPlanClient from "./CreateFloorPlanClient";

export const dynamic = 'force-dynamic';

export default function CreateFloorPlanPage() {
    return <CreateFloorPlanClient />;
}
