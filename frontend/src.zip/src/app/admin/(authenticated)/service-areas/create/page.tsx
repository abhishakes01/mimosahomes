import CreateServiceAreaClient from "./CreateServiceAreaClient";

export const dynamic = 'force-dynamic';

export default function CreateServiceAreaPage() {
    return <CreateServiceAreaClient />;
}
