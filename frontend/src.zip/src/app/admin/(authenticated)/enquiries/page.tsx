import EnquiriesClient from "./EnquiriesClient";

export const dynamic = 'force-dynamic';

export default function EnquiriesPage() {
    return <EnquiriesClient />;
}
