import CreateFacadeClient from "./CreateFacadeClient";

export const dynamic = 'force-dynamic';

export default function CreateFacadePage() {
    return <CreateFacadeClient />;
}
