import EditFacadeClient from "./EditFacadeClient";

export const dynamic = 'force-dynamic';

export default function EditFacadePage() {
    return <EditFacadeClient />;
}
