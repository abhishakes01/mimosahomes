import SettingsClient from "./SettingsClient";

export const metadata = {
    title: "System Settings | Mitra Home Admin",
};

export default function SettingsPage() {
    return <SettingsClient />;
}
