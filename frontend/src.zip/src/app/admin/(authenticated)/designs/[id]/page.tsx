
import EditListingClient from "./EditListingClient";

export const dynamic = 'force-dynamic';

export default function EditListingPage() {
    return <EditListingClient />;
}
