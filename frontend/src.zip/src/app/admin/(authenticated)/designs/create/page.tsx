
import CreateListingClient from "./CreateListingClient";

export const dynamic = 'force-dynamic';

export default function CreateListingPage() {
    return <CreateListingClient />;
}
